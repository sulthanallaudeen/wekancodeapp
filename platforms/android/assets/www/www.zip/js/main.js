$(document).ready(function () {
		
$(".loginuser").click(function(){
//    window.location.href = "dashboard.html";
alert()
});





});